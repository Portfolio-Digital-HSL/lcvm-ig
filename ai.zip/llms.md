# org.mangaradigital.fhir.lcvm-ig#0.1.0: null

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [MyPatient](StructureDefinition-MyPatient.md)

### ImplementationGuides

* [LCVMIG](index.md)

### Examples

* [PatientExample (Patient)](Patient-PatientExample.md)
